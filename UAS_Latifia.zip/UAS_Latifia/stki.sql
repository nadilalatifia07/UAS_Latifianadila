-- phpMyAdmin SQL Dump
-- version 5.0.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 17 Des 2020 pada 01.50
-- Versi server: 10.4.14-MariaDB
-- Versi PHP: 7.4.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `stki`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `berita`
--

CREATE TABLE `berita` (
  `id` int(5) NOT NULL,
  `judul` tinytext NOT NULL,
  `isi` text NOT NULL,
  `url` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `berita`
--

INSERT INTO `berita` (`id`, `judul`, `isi`, `url`) VALUES
(1, '\r\nLionel Messi Mengejar Rekor Gol Pele', 'Lionel Messi kembali ke Timnas Argentina untuk Kualifikasi Piala Dunia 2022. Messi pun mengejar rekor gol legenda Brasil, Pele di level timnas.', 'https://sport.detik.com/sepakbola/bola-dunia/d-5208964/lionel-messi-mengejar-rekor-gol-pele'),
(2, '\r\nThiago Alcantara Sudah Sembuh dari Corona?', 'Thiago Alcantara, pemain baru Liverpool diketahui positif virus Corona. Tapi sepertinya, kini dia sudah sembuh.\r\n', 'https://sport.detik.com/sepakbola/liga-inggris/d-5208947/thiago-alcantara-sudah-sembuh-dari-corona'),
(3, '\r\nHasil Kualifikasi MotoGP Prancis: Quartararo Rebut Pole', 'Rider tim Petronas Yamaha, Fabio Quartararo, menjadi yang tercepat di kualifikasi MotoGP Prancis 2020. Jack Miller dari Pramac Ducati menyusul di belakangnya.', 'https://sport.detik.com/moto-gp/d-5208451/hasil-kualifikasi-motogp-prancis-quartararo-rebut-pole'),
(4, 'Shin Tae-yong Siapkan Formasi Baru Hadapi Makedonia Utara', 'Jakarta - Tim Nasional Indonesia U-19 bersiap melakoni uji coba lanjutan melawan Makedonia Utara. Menuju itu, Garuda Muda bakal melakukan sejumlah rotasi...', 'https://sport.detik.com/sepakbola/liga-indonesia/d-5208928/shin-tae-yong-siapkan-formasi-baru-hadapi-makedonia-utara'),
(5, 'Terungkap! Klopp yang Sarankan Lallana Cabut dari Liverpool', 'Kontrak Lallana yang habis pada akhir musim lalu tak diperpanjang Liverpool. Gelandang Inggris itu kemudian dibeli Brighton & Hove Albion dengan durasi kontrak tiga tahun...', 'https://sport.detik.com/sepakbola/liga-inggris/d-5208301/terungkap-klopp-yang-sarankan-lallana-cabut-dari-liverpool'),
(6, '\r\nJika Memang Harus, MU Akan Pecat Solskjaer', 'Rumor pemecatan manajer langsung merebak di awal kompetisi Liga Inggris musim ini. Salah satunya tertuju ke manajer Manchester United, Ole Gunnar Solskjaer.\r\n', 'https://sport.detik.com/sepakbola/liga-inggris/d-5208983/jika-memang-harus-mu-akan-pecat-solskjaer'),
(7, '\r\nMauricio Pochettino Diincar Dua Manchester', 'Dua Manchester yakni Manchester City dan Manchester United kabarnya sama-sama mengincar Mauricio Pochettino. Siapa yang bakal dapat?\r\n', 'https://sport.detik.com/sepakbola/liga-inggris/d-5208917/mauricio-pochettino-diincar-dua-manchester'),
(8, '\r\nChelsea Posesif ke Hakim Ziyech, Nih', 'Hakim Ziyech, rekrutan baru Chelsea masih berjuang pulih dari cedera tapi sudah bergabung ke Timnas Maroko. Chelsea pun memulangkannya.', 'https://sport.detik.com/sepakbola/liga-inggris/d-5208894/chelsea-posesif-ke-hakim-ziyech-nih'),
(9, '\r\nBarcelona Memang Lagi Irit-irit', 'Barcelona tidak terlalu banyak gembar-gembor di bursa transfer musim panas ini. Alasannya, faktor keuangan klub.', 'https://sport.detik.com/sepakbola/liga-spanyol/d-5208856/barcelona-memang-lagi-irit-irit'),
(10, '\r\nGareth Bale Siap Main Pekan Depan?', 'Gareth Bale dikabarkan siap merumput untuk debut bersama Tottenham Hotspur pekan depan. Dirinya makin terus membaik dari cedera.', 'https://sport.detik.com/sepakbola/liga-inggris/d-5208839/gareth-bale-siap-main-pekan-depan'),
(11, '\r\nJasa Conte pada Romelu Lukaku', 'Bersama Inter Milan, Romelu Lukaku menjadi penyerang yang begitu mematikan. Ada pengaruh besar pelatih Antonio Conte di balik penampilan mengilap Lukaku.', 'https://sport.detik.com/sepakbola/liga-inggris/d-5208798/jasa-conte-pada-romelu-lukaku'),
(12, '\r\nSetelah Berpisah 15 Tahun, Higuain Bersaudara Main Bareng Lagi', 'Gonzalo Higuain kembali bermain satu klub dengan sang kakak, yakni Federico Higuain. Inter Miami baru-baru ini mengumumkan perekrutan Federico.', 'https://sport.detik.com/sepakbola/bola-dunia/d-5208789/setelah-berpisah-15-tahun-higuain-bersaudara-main-bareng-lagi'),
(13, '\r\nAkhirnya, Jerman Menang Juga di UEFA Nations League', 'Jerman memetik kemenangan atas Ukraina di lanjutan UEFA Nations League. Bagi Jerman, itu adalah kemenangan perdana mereka di ajang ini.', 'https://sport.detik.com/sepakbola/bola-dunia/d-5208784/akhirnya-jerman-menang-juga-di-uefa-nations-league'),
(14, '\r\nJika Sukses di Piala Eropa Bersama Wales, Giggs Layak Latih MU', 'Mark Hughes yakin jika Ryan Giggs bisa kembali menjadi manajer Manchester United. Giggs saat ini dinilai punya banyak pengalaman.\r\n', 'https://sport.detik.com/sepakbola/liga-inggris/d-5208730/jika-sukses-di-piala-eropa-bersama-wales-giggs-layak-latih-mu'),
(15, '\r\nCerita Bruno Fernandes Ngamuk di Ruang Ganti Saat MU Dihantam Spurs', 'Bruno Fernandes kesal betul dengan performa Manchester United saat dibenamkan Tottenham Hotspur 1-6. Fernandes tak kuasa menahan kemarahannya di ruang ganti.', 'https://sport.detik.com/sepakbola/liga-inggris/d-5208738/cerita-bruno-fernandes-ngamuk-di-ruang-ganti-saat-mu-dihantam-spurs'),
(16, '\r\nCedera, Harry Kane Terancam Absen Lawan Belgia', 'Harry Kane terancam melewatkan pertandingan Inggris vs Belgia di UEFA Nations League. Kane mengalami cedera saat latihan.', 'https://sport.detik.com/sepakbola/bola-dunia/d-5208719/cedera-harry-kane-terancam-absen-lawan-belgia'),
(17, '\r\nMan City Tak Akan Halangi Guardiola Pergi, tapi...', 'Manchester City memprioritaskan kontrak baru Pep Guardiola. Namun, seandainya Guardiola memang ingin pergi City tidak akan menghalangi.', 'https://sport.detik.com/sepakbola/liga-inggris/d-5208708/man-city-tak-akan-halangi-guardiola-pergi-tapi'),
(18, '\r\nBangganya Pulisic Warisi Nomor 10 Chelsea', 'Mulai musim 2020/2021, Christian Pulisic memakai nomor punggung 10 di Chelsea. Pulisic gembira akhirnya mendapatkan nomor yang diidam-idamkannya.', 'https://sport.detik.com/sepakbola/liga-inggris/d-5208649/bangganya-pulisic-warisi-nomor-10-chelsea'),
(19, '\r\nMemphis Depay: Ke Barcelona di Januari? Kita Lihat Saja Nanti', 'Memphis Depay gagal gabung Barcelona pada bursa transfer musim panas ini. Depay masih membuka kemungkinan untuk pindah pada bursa bulan Januari nanti.', 'https://sport.detik.com/sepakbola/liga-spanyol/d-5208638/memphis-depay-ke-barcelona-di-januari-kita-lihat-saja-nanti'),
(20, '\r\nGrealish Bukan The Next Gascoigne', 'Pelatih timnas Inggris Gareth Souhgate tak sepakat jika Jack Grealish disebut The Next Paul Gascoigne. Menurutnya, level permainan keduanya jauh berbeda.', 'https://sport.detik.com/sepakbola/liga-inggris/d-5208632/grealish-bukan-the-next-gascoigne');

-- --------------------------------------------------------

--
-- Struktur dari tabel `katakunci`
--

CREATE TABLE `katakunci` (
  `id` int(5) NOT NULL,
  `kata` varchar(26) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `katakunci`
--

INSERT INTO `katakunci` (`id`, `kata`) VALUES
(0, '');

-- --------------------------------------------------------

--
-- Struktur dari tabel `stopword`
--

CREATE TABLE `stopword` (
  `stopword` varchar(25) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Struktur dari tabel `token`
--

CREATE TABLE `token` (
  `id` varchar(5) NOT NULL,
  `no` varchar(5) NOT NULL,
  `kode` varchar(5) NOT NULL,
  `kata` varchar(50) NOT NULL,
  `freq` varchar(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `token`
--

INSERT INTO `token` (`id`, `no`, `kode`, `kata`, `freq`) VALUES
('1', '1', '0', 'lionel', '1'),
('1', '2', '0', 'messi', '1'),
('1', '3', '0', 'kembali', '1'),
('1', '4', '0', 'ke', '1'),
('1', '5', '0', 'timnas', '1'),
('1', '6', '0', 'argentina', '1'),
('1', '7', '0', 'untuk', '1'),
('1', '8', '0', 'kualifikasi', '1'),
('1', '9', '0', 'piala', '1'),
('1', '10', '0', 'dunia', '1'),
('1', '11', '0', 'messi', '1'),
('1', '12', '0', 'pun', '1'),
('1', '13', '0', 'mengejar', '1'),
('1', '14', '0', 'rekor', '1'),
('1', '15', '0', 'gol', '1'),
('1', '16', '0', 'legenda', '1'),
('1', '17', '0', 'brasil', '1'),
('1', '18', '0', 'pele', '1'),
('1', '19', '0', 'di', '1'),
('1', '20', '0', 'level', '1'),
('1', '21', '0', 'timnas', '1'),
('2', '1', '0', 'thiago', '1'),
('2', '2', '0', 'alcantara', '1'),
('2', '3', '0', 'pemain', '1'),
('2', '4', '0', 'baru', '1'),
('2', '5', '0', 'liverpool', '1'),
('2', '6', '0', 'diketahui', '1'),
('2', '7', '0', 'positif', '1'),
('2', '8', '0', 'virus', '1'),
('2', '9', '0', 'corona', '1'),
('2', '10', '0', 'tapi', '1'),
('2', '11', '0', 'sepertinya', '1'),
('2', '12', '0', 'kini', '1'),
('2', '13', '0', 'dia', '1'),
('2', '14', '0', 'sudah', '1'),
('2', '15', '0', 'sembuh', '1'),
('3', '1', '0', 'rider', '1'),
('3', '2', '0', 'tim', '1'),
('3', '3', '0', 'petronas', '1'),
('3', '4', '0', 'yamaha', '1'),
('3', '5', '0', 'fabio', '1'),
('3', '6', '0', 'quartararo', '1'),
('3', '7', '0', 'menjadi', '1'),
('3', '8', '0', 'yang', '1'),
('3', '9', '0', 'tercepat', '1'),
('3', '10', '0', 'di', '1'),
('3', '11', '0', 'kualifikasi', '1'),
('3', '12', '0', 'motogp', '1'),
('3', '13', '0', 'prancis', '1'),
('3', '14', '0', 'jack', '1'),
('3', '15', '0', 'miller', '1'),
('3', '16', '0', 'dari', '1'),
('3', '17', '0', 'pramac', '1'),
('3', '18', '0', 'ducati', '1'),
('3', '19', '0', 'menyusul', '1'),
('3', '20', '0', 'di', '1'),
('3', '21', '0', 'belakangnya', '1'),
('4', '1', '0', 'jakarta', '1'),
('4', '2', '0', 'tim', '1'),
('4', '3', '0', 'nasional', '1'),
('4', '4', '0', 'indonesia', '1'),
('4', '5', '0', 'u', '1'),
('4', '6', '0', 'bersiap', '1'),
('4', '7', '0', 'melakoni', '1'),
('4', '8', '0', 'uji', '1'),
('4', '9', '0', 'coba', '1'),
('4', '10', '0', 'lanjutan', '1'),
('4', '11', '0', 'melawan', '1'),
('4', '12', '0', 'makedonia', '1'),
('4', '13', '0', 'utara', '1'),
('4', '14', '0', 'menuju', '1'),
('4', '15', '0', 'itu', '1'),
('4', '16', '0', 'garuda', '1'),
('4', '17', '0', 'muda', '1'),
('4', '18', '0', 'bakal', '1'),
('4', '19', '0', 'melakukan', '1'),
('4', '20', '0', 'sejumlah', '1'),
('4', '21', '0', 'rotasi', '1'),
('5', '1', '0', 'kontrak', '1'),
('5', '2', '0', 'lallana', '1'),
('5', '3', '0', 'yang', '1'),
('5', '4', '0', 'habis', '1'),
('5', '5', '0', 'pada', '1'),
('5', '6', '0', 'akhir', '1'),
('5', '7', '0', 'musim', '1'),
('5', '8', '0', 'lalu', '1'),
('5', '9', '0', 'tak', '1'),
('5', '10', '0', 'diperpanjang', '1'),
('5', '11', '0', 'liverpool', '1'),
('5', '12', '0', 'gelandang', '1'),
('5', '13', '0', 'inggris', '1'),
('5', '14', '0', 'itu', '1'),
('5', '15', '0', 'kemudian', '1'),
('5', '16', '0', 'dibeli', '1'),
('5', '17', '0', 'brighton', '1'),
('5', '18', '0', 'hove', '1'),
('5', '19', '0', 'albion', '1'),
('5', '20', '0', 'dengan', '1'),
('5', '21', '0', 'durasi', '1'),
('5', '22', '0', 'kontrak', '1'),
('5', '23', '0', 'tiga', '1'),
('5', '24', '0', 'tahun', '1'),
('6', '1', '0', 'rumor', '1'),
('6', '2', '0', 'pemecatan', '1'),
('6', '3', '0', 'manajer', '1'),
('6', '4', '0', 'langsung', '1'),
('6', '5', '0', 'merebak', '1'),
('6', '6', '0', 'di', '1'),
('6', '7', '0', 'awal', '1'),
('6', '8', '0', 'kompetisi', '1'),
('6', '9', '0', 'liga', '1'),
('6', '10', '0', 'inggris', '1'),
('6', '11', '0', 'musim', '1'),
('6', '12', '0', 'ini', '1'),
('6', '13', '0', 'salah', '1'),
('6', '14', '0', 'satunya', '1'),
('6', '15', '0', 'tertuju', '1'),
('6', '16', '0', 'ke', '1'),
('6', '17', '0', 'manajer', '1'),
('6', '18', '0', 'manchester', '1'),
('6', '19', '0', 'united', '1'),
('6', '20', '0', 'ole', '1'),
('6', '21', '0', 'gunnar', '1'),
('6', '22', '0', 'solskjaer', '1'),
('7', '1', '0', 'dua', '1'),
('7', '2', '0', 'manchester', '1'),
('7', '3', '0', 'yakni', '1'),
('7', '4', '0', 'manchester', '1'),
('7', '5', '0', 'city', '1'),
('7', '6', '0', 'dan', '1'),
('7', '7', '0', 'manchester', '1'),
('7', '8', '0', 'united', '1'),
('7', '9', '0', 'kabarnya', '1'),
('7', '10', '0', 'sama', '1'),
('7', '11', '0', 'sama', '1'),
('7', '12', '0', 'mengincar', '1'),
('7', '13', '0', 'mauricio', '1'),
('7', '14', '0', 'pochettino', '1'),
('7', '15', '0', 'siapa', '1'),
('7', '16', '0', 'yang', '1'),
('7', '17', '0', 'bakal', '1'),
('7', '18', '0', 'dapat', '1'),
('8', '1', '0', 'hakim', '1'),
('8', '2', '0', 'ziyech', '1'),
('8', '3', '0', 'rekrutan', '1'),
('8', '4', '0', 'baru', '1'),
('8', '5', '0', 'chelsea', '1'),
('8', '6', '0', 'masih', '1'),
('8', '7', '0', 'berjuang', '1'),
('8', '8', '0', 'pulih', '1'),
('8', '9', '0', 'dari', '1'),
('8', '10', '0', 'cedera', '1'),
('8', '11', '0', 'tapi', '1'),
('8', '12', '0', 'sudah', '1'),
('8', '13', '0', 'bergabung', '1'),
('8', '14', '0', 'ke', '1'),
('8', '15', '0', 'timnas', '1'),
('8', '16', '0', 'maroko', '1'),
('8', '17', '0', 'chelsea', '1'),
('8', '18', '0', 'pun', '1'),
('8', '19', '0', 'memulangkannya', '1'),
('9', '1', '0', 'barcelona', '1'),
('9', '2', '0', 'tidak', '1'),
('9', '3', '0', 'terlalu', '1'),
('9', '4', '0', 'banyak', '1'),
('9', '5', '0', 'gembar', '1'),
('9', '6', '0', 'gembor', '1'),
('9', '7', '0', 'di', '1'),
('9', '8', '0', 'bursa', '1'),
('9', '9', '0', 'transfer', '1'),
('9', '10', '0', 'musim', '1'),
('9', '11', '0', 'panas', '1'),
('9', '12', '0', 'ini', '1'),
('9', '13', '0', 'alasannya', '1'),
('9', '14', '0', 'faktor', '1'),
('9', '15', '0', 'keuangan', '1'),
('9', '16', '0', 'klub', '1'),
('10', '1', '0', 'gareth', '1'),
('10', '2', '0', 'bale', '1'),
('10', '3', '0', 'dikabarkan', '1'),
('10', '4', '0', 'siap', '1'),
('10', '5', '0', 'merumput', '1'),
('10', '6', '0', 'untuk', '1'),
('10', '7', '0', 'debut', '1'),
('10', '8', '0', 'bersama', '1'),
('10', '9', '0', 'tottenham', '1'),
('10', '10', '0', 'hotspur', '1'),
('10', '11', '0', 'pekan', '1'),
('10', '12', '0', 'depan', '1'),
('10', '13', '0', 'dirinya', '1'),
('10', '14', '0', 'makin', '1'),
('10', '15', '0', 'terus', '1'),
('10', '16', '0', 'membaik', '1'),
('10', '17', '0', 'dari', '1'),
('10', '18', '0', 'cedera', '1'),
('11', '1', '0', 'bersama', '1'),
('11', '2', '0', 'inter', '1'),
('11', '3', '0', 'milan', '1'),
('11', '4', '0', 'romelu', '1'),
('11', '5', '0', 'lukaku', '1'),
('11', '6', '0', 'menjadi', '1'),
('11', '7', '0', 'penyerang', '1'),
('11', '8', '0', 'yang', '1'),
('11', '9', '0', 'begitu', '1'),
('11', '10', '0', 'mematikan', '1'),
('11', '11', '0', 'ada', '1'),
('11', '12', '0', 'pengaruh', '1'),
('11', '13', '0', 'besar', '1'),
('11', '14', '0', 'pelatih', '1'),
('11', '15', '0', 'antonio', '1'),
('11', '16', '0', 'conte', '1'),
('11', '17', '0', 'di', '1'),
('11', '18', '0', 'balik', '1'),
('11', '19', '0', 'penampilan', '1'),
('11', '20', '0', 'mengilap', '1'),
('11', '21', '0', 'lukaku', '1'),
('12', '1', '0', 'gonzalo', '1'),
('12', '2', '0', 'higuain', '1'),
('12', '3', '0', 'kembali', '1'),
('12', '4', '0', 'bermain', '1'),
('12', '5', '0', 'satu', '1'),
('12', '6', '0', 'klub', '1'),
('12', '7', '0', 'dengan', '1'),
('12', '8', '0', 'sang', '1'),
('12', '9', '0', 'kakak', '1'),
('12', '10', '0', 'yakni', '1'),
('12', '11', '0', 'federico', '1'),
('12', '12', '0', 'higuain', '1'),
('12', '13', '0', 'inter', '1'),
('12', '14', '0', 'miami', '1'),
('12', '15', '0', 'baru', '1'),
('12', '16', '0', 'baru', '1'),
('12', '17', '0', 'ini', '1'),
('12', '18', '0', 'mengumumkan', '1'),
('12', '19', '0', 'perekrutan', '1'),
('12', '20', '0', 'federico', '1'),
('13', '1', '0', 'jerman', '1'),
('13', '2', '0', 'memetik', '1'),
('13', '3', '0', 'kemenangan', '1'),
('13', '4', '0', 'atas', '1'),
('13', '5', '0', 'ukraina', '1'),
('13', '6', '0', 'di', '1'),
('13', '7', '0', 'lanjutan', '1'),
('13', '8', '0', 'uefa', '1'),
('13', '9', '0', 'nations', '1'),
('13', '10', '0', 'league', '1'),
('13', '11', '0', 'bagi', '1'),
('13', '12', '0', 'jerman', '1'),
('13', '13', '0', 'itu', '1'),
('13', '14', '0', 'adalah', '1'),
('13', '15', '0', 'kemenangan', '1'),
('13', '16', '0', 'perdana', '1'),
('13', '17', '0', 'mereka', '1'),
('13', '18', '0', 'di', '1'),
('13', '19', '0', 'ajang', '1'),
('13', '20', '0', 'ini', '1'),
('14', '1', '0', 'mark', '1'),
('14', '2', '0', 'hughes', '1'),
('14', '3', '0', 'yakin', '1'),
('14', '4', '0', 'jika', '1'),
('14', '5', '0', 'ryan', '1'),
('14', '6', '0', 'giggs', '1'),
('14', '7', '0', 'bisa', '1'),
('14', '8', '0', 'kembali', '1'),
('14', '9', '0', 'menjadi', '1'),
('14', '10', '0', 'manajer', '1'),
('14', '11', '0', 'manchester', '1'),
('14', '12', '0', 'united', '1'),
('14', '13', '0', 'giggs', '1'),
('14', '14', '0', 'saat', '1'),
('14', '15', '0', 'ini', '1'),
('14', '16', '0', 'dinilai', '1'),
('14', '17', '0', 'punya', '1'),
('14', '18', '0', 'banyak', '1'),
('14', '19', '0', 'pengalaman', '1'),
('15', '1', '0', 'bruno', '1'),
('15', '2', '0', 'fernandes', '1'),
('15', '3', '0', 'kesal', '1'),
('15', '4', '0', 'betul', '1'),
('15', '5', '0', 'dengan', '1'),
('15', '6', '0', 'performa', '1'),
('15', '7', '0', 'manchester', '1'),
('15', '8', '0', 'united', '1'),
('15', '9', '0', 'saat', '1'),
('15', '10', '0', 'dibenamkan', '1'),
('15', '11', '0', 'tottenham', '1'),
('15', '12', '0', 'hotspur', '1'),
('15', '13', '0', 'fernandes', '1'),
('15', '14', '0', 'tak', '1'),
('15', '15', '0', 'kuasa', '1'),
('15', '16', '0', 'menahan', '1'),
('15', '17', '0', 'kemarahannya', '1'),
('15', '18', '0', 'di', '1'),
('15', '19', '0', 'ruang', '1'),
('15', '20', '0', 'ganti', '1'),
('16', '1', '0', 'harry', '1'),
('16', '2', '0', 'kane', '1'),
('16', '3', '0', 'terancam', '1'),
('16', '4', '0', 'melewatkan', '1'),
('16', '5', '0', 'pertandingan', '1'),
('16', '6', '0', 'inggris', '1'),
('16', '7', '0', 'vs', '1'),
('16', '8', '0', 'belgia', '1'),
('16', '9', '0', 'di', '1'),
('16', '10', '0', 'uefa', '1'),
('16', '11', '0', 'nations', '1'),
('16', '12', '0', 'league', '1'),
('16', '13', '0', 'kane', '1'),
('16', '14', '0', 'mengalami', '1'),
('16', '15', '0', 'cedera', '1'),
('16', '16', '0', 'saat', '1'),
('16', '17', '0', 'latihan', '1'),
('17', '1', '0', 'manchester', '1'),
('17', '2', '0', 'city', '1'),
('17', '3', '0', 'memprioritaskan', '1'),
('17', '4', '0', 'kontrak', '1'),
('17', '5', '0', 'baru', '1'),
('17', '6', '0', 'pep', '1'),
('17', '7', '0', 'guardiola', '1'),
('17', '8', '0', 'namun', '1'),
('17', '9', '0', 'seandainya', '1'),
('17', '10', '0', 'guardiola', '1'),
('17', '11', '0', 'memang', '1'),
('17', '12', '0', 'ingin', '1'),
('17', '13', '0', 'pergi', '1'),
('17', '14', '0', 'city', '1'),
('17', '15', '0', 'tidak', '1'),
('17', '16', '0', 'akan', '1'),
('17', '17', '0', 'menghalangi', '1'),
('18', '1', '0', 'mulai', '1'),
('18', '2', '0', 'musim', '1'),
('18', '3', '0', 'christian', '1'),
('18', '4', '0', 'pulisic', '1'),
('18', '5', '0', 'memakai', '1'),
('18', '6', '0', 'nomor', '1'),
('18', '7', '0', 'punggung', '1'),
('18', '8', '0', 'di', '1'),
('18', '9', '0', 'chelsea', '1'),
('18', '10', '0', 'pulisic', '1'),
('18', '11', '0', 'gembira', '1'),
('18', '12', '0', 'akhirnya', '1'),
('18', '13', '0', 'mendapatkan', '1'),
('18', '14', '0', 'nomor', '1'),
('18', '15', '0', 'yang', '1'),
('18', '16', '0', 'diidam', '1'),
('18', '17', '0', 'idamkannya', '1'),
('19', '1', '0', 'memphis', '1'),
('19', '2', '0', 'depay', '1'),
('19', '3', '0', 'gagal', '1'),
('19', '4', '0', 'gabung', '1'),
('19', '5', '0', 'barcelona', '1'),
('19', '6', '0', 'pada', '1'),
('19', '7', '0', 'bursa', '1'),
('19', '8', '0', 'transfer', '1'),
('19', '9', '0', 'musim', '1'),
('19', '10', '0', 'panas', '1'),
('19', '11', '0', 'ini', '1'),
('19', '12', '0', 'depay', '1'),
('19', '13', '0', 'masih', '1'),
('19', '14', '0', 'membuka', '1'),
('19', '15', '0', 'kemungkinan', '1'),
('19', '16', '0', 'untuk', '1'),
('19', '17', '0', 'pindah', '1'),
('19', '18', '0', 'pada', '1'),
('19', '19', '0', 'bursa', '1'),
('19', '20', '0', 'bulan', '1'),
('19', '21', '0', 'januari', '1'),
('19', '22', '0', 'nanti', '1'),
('20', '1', '0', 'pelatih', '1'),
('20', '2', '0', 'timnas', '1'),
('20', '3', '0', 'inggris', '1'),
('20', '4', '0', 'gareth', '1'),
('20', '5', '0', 'souhgate', '1'),
('20', '6', '0', 'tak', '1'),
('20', '7', '0', 'sepakat', '1'),
('20', '8', '0', 'jika', '1'),
('20', '9', '0', 'jack', '1'),
('20', '10', '0', 'grealish', '1'),
('20', '11', '0', 'disebut', '1'),
('20', '12', '0', 'the', '1'),
('20', '13', '0', 'next', '1'),
('20', '14', '0', 'paul', '1'),
('20', '15', '0', 'gascoigne', '1'),
('20', '16', '0', 'menurutnya', '1'),
('20', '17', '0', 'level', '1'),
('20', '18', '0', 'permainan', '1'),
('20', '19', '0', 'keduanya', '1'),
('20', '20', '0', 'jauh', '1'),
('20', '21', '0', 'berbeda', '1');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `berita`
--
ALTER TABLE `berita`
  ADD KEY `hasil` (`id`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `berita`
--
ALTER TABLE `berita`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
